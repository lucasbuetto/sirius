angular.module('app.controllers', [])
  
.controller('loginCtrl', function($scope) {

})
   
.controller('filtrosCtrl', function($scope) {

})
   
.controller('padrõEsCtrl', function($scope) {

})
 